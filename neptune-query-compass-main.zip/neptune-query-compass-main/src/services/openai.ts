// OpenAI service for query processing
// Note: In a production app, API calls should be made from your backend to keep API keys secure

export interface QueryAnalysis {
  serviceType: string;
  location: string;
  requirements: string[];
  intent: string;
}

export const analyzeQuery = async (query: string, apiKey?: string): Promise<QueryAnalysis> => {
  // Mock analysis for demo purposes
  // In a real app, you would send this to OpenAI or another LLM
  
  console.log("Analyzing query:", query);
  
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Mock response based on common patterns
  const mockAnalysis: QueryAnalysis = {
    serviceType: extractServiceType(query),
    location: extractLocation(query),
    requirements: extractRequirements(query),
    intent: "find_service_providers"
  };
  
  return mockAnalysis;
};

const extractServiceType = (query: string): string => {
  const services = {
    'dishwasher': 'Appliance Repair',
    'plumber': 'Plumbing',
    'electrician': 'Electrical',
    'hvac': 'HVAC',
    'carpenter': 'Carpentry',
    'painter': 'Painting'
  };
  
  for (const [keyword, service] of Object.entries(services)) {
    if (query.toLowerCase().includes(keyword)) {
      return service;
    }
  }
  
  return 'General Services';
};

const extractLocation = (query: string): string => {
  const locations = ['san francisco', 'sf', 'bay area', 'california', 'ca'];
  
  for (const location of locations) {
    if (query.toLowerCase().includes(location)) {
      return 'San Francisco, CA';
    }
  }
  
  return 'Local Area';
};

const extractRequirements = (query: string): string[] => {
  const requirements = [];
  
  if (query.toLowerCase().includes('best') || query.toLowerCase().includes('top')) {
    requirements.push('high_rating');
  }
  
  if (query.toLowerCase().includes('cheap') || query.toLowerCase().includes('affordable')) {
    requirements.push('budget_friendly');
  }
  
  if (query.toLowerCase().includes('emergency') || query.toLowerCase().includes('24/7')) {
    requirements.push('emergency_service');
  }
  
  if (query.toLowerCase().includes('licensed') || query.toLowerCase().includes('certified')) {
    requirements.push('licensed');
  }
  
  return requirements;
};

// Real OpenAI integration (commented out for demo)
/*
export const analyzeQueryWithOpenAI = async (query: string, apiKey: string): Promise<QueryAnalysis> => {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'You are an expert at analyzing service requests. Extract the service type, location, and specific requirements from user queries.'
        },
        {
          role: 'user',
          content: `Analyze this service request: "${query}". Return JSON with serviceType, location, requirements array, and intent.`
        }
      ],
      temperature: 0.1,
      max_tokens: 300,
    }),
  });

  const data = await response.json();
  return JSON.parse(data.choices[0].message.content);
};
*/
