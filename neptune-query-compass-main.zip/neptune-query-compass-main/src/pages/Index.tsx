
import { useState } from "react";
import SearchInterface from "@/components/SearchInterface";
import ResultsDisplay from "@/components/ResultsDisplay";
import { ServiceProvider } from "@/types/ServiceProvider";

const Index = () => {
  const [results, setResults] = useState<ServiceProvider[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [query, setQuery] = useState("");

  const handleSearch = async (searchQuery: string) => {
    setIsLoading(true);
    setQuery(searchQuery);
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock results - in a real app, this would come from your backend
      const mockResults: ServiceProvider[] = [
        {
          id: "1",
          name: "TechFix Pro Services",
          rating: 4.8,
          reviewCount: 127,
          priceRange: "$80-120/hour",
          description: "Certified appliance repair specialists with 15+ years experience. Same-day service available.",
          phone: "(415) 555-0123",
          address: "1234 Mission St, San Francisco, CA",
          specialties: ["Dishwashers", "Washing Machines", "Dryers"],
          availability: "Mon-Sat 8AM-6PM",
          bookingUrl: "https://techfixpro.com/book",
          sources: ["Yelp", "Google Business", "Angie's List"]
        },
        {
          id: "2",
          name: "Bay Area Appliance Experts",
          rating: 4.6,
          reviewCount: 89,
          priceRange: "$75-100/hour",
          description: "Family-owned business serving SF Bay Area for 20 years. Free estimates and warranty on all repairs.",
          phone: "(415) 555-0456",
          address: "5678 Geary Blvd, San Francisco, CA",
          specialties: ["All Major Appliances", "Emergency Repairs"],
          availability: "24/7 Emergency Service",
          bookingUrl: "https://bayareaexperts.com/schedule",
          sources: ["HomeAdvisor", "Thumbtack", "Google Business"]
        },
        {
          id: "3",
          name: "Quick Fix Appliance Repair",
          rating: 4.7,
          reviewCount: 156,
          priceRange: "$70-95/hour",
          description: "Licensed and insured professionals. Specializing in dishwasher repairs with guaranteed satisfaction.",
          phone: "(415) 555-0789",
          address: "9012 Irving St, San Francisco, CA",
          specialties: ["Dishwashers", "Garbage Disposals", "Kitchen Appliances"],
          availability: "Mon-Fri 7AM-7PM, Sat 9AM-5PM",
          bookingUrl: "https://quickfixsf.com/book-now",
          sources: ["Yelp", "Better Business Bureau", "NextDoor"]
        }
      ];
      
      setResults(mockResults);
    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            ServiceFinder AI
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Find the best local service providers using natural language search powered by AI
          </p>
        </div>
        
        <SearchInterface onSearch={handleSearch} isLoading={isLoading} />
        
        {results.length > 0 && (
          <ResultsDisplay 
            results={results} 
            query={query}
            isLoading={isLoading}
          />
        )}
      </div>
    </div>
  );
};

export default Index;
