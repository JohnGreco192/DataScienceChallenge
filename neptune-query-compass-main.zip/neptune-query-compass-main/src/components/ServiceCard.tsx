
import { ServiceProvider } from "@/types/ServiceProvider";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Phone, MapPin, Clock, ExternalLink } from "lucide-react";
import NeptuneScore from "./NeptuneScore";

interface ServiceCardProps {
  provider: ServiceProvider;
}

const ServiceCard = ({ provider }: ServiceCardProps) => {
  return (
    <Card className="h-full hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-border/50">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-semibold text-foreground line-clamp-2">
            {provider.name}
          </h3>
          <NeptuneScore provider={provider} />
        </div>
        
        <div className="flex items-center gap-2 mb-2">
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
            <span className="font-medium">{provider.rating}</span>
            <span className="text-muted-foreground text-sm">
              ({provider.reviewCount} reviews)
            </span>
          </div>
        </div>

        <div className="flex flex-wrap gap-1 mb-3">
          {provider.specialties.slice(0, 2).map((specialty, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {specialty}
            </Badge>
          ))}
          {provider.specialties.length > 2 && (
            <Badge variant="outline" className="text-xs">
              +{provider.specialties.length - 2} more
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
          {provider.description}
        </p>

        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-2 text-sm">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground truncate">{provider.address}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            <Phone className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">{provider.phone}</span>
          </div>

          <div className="flex items-center gap-2 text-sm">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">{provider.availability}</span>
          </div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-lg font-semibold text-foreground">
              {provider.priceRange}
            </span>
          </div>
        </div>

        <div className="space-y-2">
          <Button 
            className="w-full" 
            onClick={() => window.open(provider.bookingUrl, '_blank')}
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Book Now
          </Button>
          
          <div className="text-xs text-muted-foreground text-center">
            Sources: {provider.sources.join(', ')}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ServiceCard;
