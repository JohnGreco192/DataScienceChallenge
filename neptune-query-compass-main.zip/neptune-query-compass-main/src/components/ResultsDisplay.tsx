
import { ServiceProvider } from "@/types/ServiceProvider";
import ServiceCard from "./ServiceCard";
import { Loader2 } from "lucide-react";

interface ResultsDisplayProps {
  results: ServiceProvider[];
  query: string;
  isLoading: boolean;
}

const ResultsDisplay = ({ results, query, isLoading }: ResultsDisplayProps) => {
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">
            Searching across multiple sources and analyzing results...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-semibold text-foreground mb-2">
          Search Results for: "{query}"
        </h2>
        <p className="text-muted-foreground">
          Found {results.length} highly-rated service providers • Synthesized from multiple sources
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {results.map((provider) => (
          <ServiceCard key={provider.id} provider={provider} />
        ))}
      </div>

      <div className="mt-8 p-4 bg-muted/50 rounded-lg">
        <h3 className="font-semibold mb-2">About Neptune Scores</h3>
        <p className="text-sm text-muted-foreground">
          Neptune Scores are calculated based on customer ratings (40%), number of reviews (25%), 
          price competitiveness (20%), and availability (15%). Scores range from 0-100, 
          with 80+ indicating exceptional service providers.
        </p>
      </div>
    </div>
  );
};

export default ResultsDisplay;
