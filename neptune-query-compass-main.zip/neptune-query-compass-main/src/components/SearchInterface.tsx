
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Loader2 } from "lucide-react";

interface SearchInterfaceProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
}

const SearchInterface = ({ onSearch, isLoading }: SearchInterfaceProps) => {
  const [query, setQuery] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query.trim());
    }
  };

  const exampleQueries = [
    "Best dishwasher repair in San Francisco",
    "24/7 plumber near me with good reviews",
    "Affordable electrician in downtown SF"
  ];

  return (
    <div className="max-w-4xl mx-auto mb-12">
      <form onSubmit={handleSubmit} className="relative mb-6">
        <div className="relative">
          <Input
            type="text"
            placeholder="Ask me anything... e.g., 'Who are the best-rated dishwasher repair technicians in San Francisco?'"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full h-14 pl-6 pr-24 text-lg border-2 border-border/50 rounded-xl focus:border-primary shadow-lg"
            disabled={isLoading}
          />
          <Button
            type="submit"
            disabled={isLoading || !query.trim()}
            className="absolute right-2 top-2 h-10 px-6 rounded-lg"
          >
            {isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <>
                <Search className="h-5 w-5 mr-2" />
                Search
              </>
            )}
          </Button>
        </div>
      </form>

      <div className="text-center">
        <p className="text-sm text-muted-foreground mb-3">Try these example queries:</p>
        <div className="flex flex-wrap justify-center gap-2">
          {exampleQueries.map((example, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              onClick={() => setQuery(example)}
              disabled={isLoading}
              className="text-xs rounded-full"
            >
              {example}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SearchInterface;
