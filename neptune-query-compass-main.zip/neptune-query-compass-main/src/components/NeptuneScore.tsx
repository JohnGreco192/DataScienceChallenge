
import { ServiceProvider, NeptuneScoreBreakdown } from "@/types/ServiceProvider";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface NeptuneScoreProps {
  provider: ServiceProvider;
}

const calculateNeptuneScore = (provider: ServiceProvider): NeptuneScoreBreakdown => {
  // Rating component (40% weight) - normalized to 0-40 scale
  const ratingScore = (provider.rating / 5) * 40;
  
  // Review count component (25% weight) - logarithmic scale for review count
  const reviewScore = Math.min(Math.log10(provider.reviewCount + 1) / Math.log10(200) * 25, 25);
  
  // Price value component (20% weight) - lower prices get higher scores
  const priceValue = (() => {
    const priceStr = provider.priceRange.toLowerCase();
    if (priceStr.includes('70') || priceStr.includes('75')) return 20;
    if (priceStr.includes('80') || priceStr.includes('95')) return 15;
    if (priceStr.includes('100') || priceStr.includes('120')) return 10;
    return 12;
  })();
  
  // Availability component (15% weight)
  const availabilityScore = (() => {
    const avail = provider.availability.toLowerCase();
    if (avail.includes('24/7') || avail.includes('emergency')) return 15;
    if (avail.includes('mon-sat') || avail.includes('7am')) return 12;
    if (avail.includes('mon-fri')) return 10;
    return 8;
  })();

  const total = Math.round(ratingScore + reviewScore + priceValue + availabilityScore);

  return {
    rating: Math.round(ratingScore),
    reviewCount: Math.round(reviewScore),
    priceValue: Math.round(priceValue),
    availability: Math.round(availabilityScore),
    total
  };
};

const NeptuneScore = ({ provider }: NeptuneScoreProps) => {
  const score = calculateNeptuneScore(provider);
  
  const getScoreColor = (total: number) => {
    if (total >= 80) return "bg-green-500";
    if (total >= 70) return "bg-blue-500";
    if (total >= 60) return "bg-yellow-500";
    return "bg-orange-500";
  };

  const getScoreLabel = (total: number) => {
    if (total >= 80) return "Exceptional";
    if (total >= 70) return "Excellent";
    if (total >= 60) return "Good";
    return "Fair";
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger>
          <div className="text-center">
            <Badge className={`${getScoreColor(score.total)} text-white font-bold px-3 py-1`}>
              {score.total}
            </Badge>
            <div className="text-xs text-muted-foreground mt-1">
              Neptune Score
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent side="left" className="max-w-xs">
          <div className="space-y-2">
            <div className="font-semibold">Neptune Score Breakdown</div>
            <div className="text-sm space-y-1">
              <div>Rating: {score.rating}/40 (based on {provider.rating}★)</div>
              <div>Reviews: {score.reviewCount}/25 ({provider.reviewCount} reviews)</div>
              <div>Price Value: {score.priceValue}/20</div>
              <div>Availability: {score.availability}/15</div>
              <div className="border-t pt-1 font-medium">
                Total: {score.total}/100 • {getScoreLabel(score.total)}
              </div>
            </div>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default NeptuneScore;
