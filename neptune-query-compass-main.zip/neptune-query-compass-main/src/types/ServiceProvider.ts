
export interface ServiceProvider {
  id: string;
  name: string;
  rating: number;
  reviewCount: number;
  priceRange: string;
  description: string;
  phone: string;
  address: string;
  specialties: string[];
  availability: string;
  bookingUrl: string;
  sources: string[];
}

export interface NeptuneScoreBreakdown {
  rating: number;
  reviewCount: number;
  priceValue: number;
  availability: number;
  total: number;
}
